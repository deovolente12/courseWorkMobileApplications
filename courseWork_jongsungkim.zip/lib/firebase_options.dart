import 'package:firebase_core/firebase_core.dart';

// Replace these options with the settings from your Firebase project settings.
const FirebaseOptions firebaseOptions = FirebaseOptions(
  apiKey: "AIzaSyB64tN01KdRnHNhJMbOYACSeQDfiBWBP4U",
  authDomain: "translationapplication-e1c30.firebaseapp.com",
  projectId: "translationapplication-e1c30",
  storageBucket: "translationapplication-e1c30.appspot.com",
  messagingSenderId: "22415773245",
  appId: "1:22415773245:android:24abf48008a5e6cb9f2454",
);