package com.example.coursework_jongsungkim

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
